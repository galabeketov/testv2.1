import styled from "styled-components";
// import TranslateGame from "./Translate";

const ListeningGameWrapper = styled.div`
  .translate-header {
    padding: 10px 20px;
    h2 {
      font-size: 24px;
    }
  }
  .translate-body {
    .translate-question-box {
    }
  }
`;

export default ListeningGameWrapper;
